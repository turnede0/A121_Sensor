var md__home_ai_jenkins_workspace_sw_main_0d2_doc_user_guides_a121_rss_user_guide_main =
[
    [ "Sparse IQ Service", "sparse_iq.html", [
      [ "Memory Requirements", "sparse_iq.html#autotoc_md38", [
        [ "Flash footprint", "sparse_iq.html#autotoc_md39", null ],
        [ "Heap usage", "sparse_iq.html#autotoc_md40", null ]
      ] ],
      [ "Setting up the Service", "sparse_iq.html#autotoc_md41", [
        [ "Initializing the System", "sparse_iq.html#autotoc_md42", null ],
        [ "Service API", "sparse_iq.html#autotoc_md43", [
          [ "Register HAL", "sparse_iq.html#autotoc_md44", null ],
          [ "Create Configuration", "sparse_iq.html#autotoc_md45", null ],
          [ "Allocate Memory", "sparse_iq.html#autotoc_md46", null ],
          [ "Create Sensor", "sparse_iq.html#autotoc_md47", null ],
          [ "Create Processing", "sparse_iq.html#autotoc_md48", null ],
          [ "Prepare Sensor", "sparse_iq.html#autotoc_md49", null ],
          [ "Measure and Acquire Data from Sensor", "sparse_iq.html#autotoc_md50", null ],
          [ "Execute Data Processing", "sparse_iq.html#autotoc_md51", null ],
          [ "Shutdown and Memory De-allocation", "sparse_iq.html#autotoc_md52", null ]
        ] ],
        [ "Sparse IQ Service Configuration", "sparse_iq.html#autotoc_md53", [
          [ "Service Configuration", "sparse_iq.html#autotoc_md54", [
            [ "Number of subsweeps", "sparse_iq.html#autotoc_md55", null ],
            [ "Sweeps Per Frame", "sparse_iq.html#autotoc_md56", null ],
            [ "Sweep Rate", "sparse_iq.html#autotoc_md57", null ],
            [ "Continuous Sweep Mode", "sparse_iq.html#autotoc_md58", null ],
            [ "Frame Rate", "sparse_iq.html#autotoc_md59", null ],
            [ "Idle States", "sparse_iq.html#autotoc_md60", null ],
            [ "Double Buffering", "sparse_iq.html#autotoc_md61", null ]
          ] ],
          [ "Configuration without Subsweeps - Single Sweep", "sparse_iq.html#autotoc_md62", [
            [ "Start Point", "sparse_iq.html#autotoc_md63", null ],
            [ "Number of Points", "sparse_iq.html#autotoc_md64", null ]
          ] ],
          [ "Step Length", "sparse_iq.html#autotoc_md65", [
            [ "Profile", "sparse_iq.html#autotoc_md66", null ],
            [ "Hardware Accelerated Average Samples - HWAAS", "sparse_iq.html#autotoc_md67", null ],
            [ "Receiver Gain", "sparse_iq.html#autotoc_md68", null ],
            [ "TX Enable", "sparse_iq.html#autotoc_md69", null ],
            [ "Pulse Repetition Frequency", "sparse_iq.html#autotoc_md70", null ],
            [ "Phase Enhancement", "sparse_iq.html#autotoc_md71", null ],
            [ "Enable Loopback", "sparse_iq.html#autotoc_md72", null ]
          ] ],
          [ "Configuration with Subsweeps - Multiple Sweeps", "sparse_iq.html#autotoc_md73", [
            [ "Start Point", "sparse_iq.html#autotoc_md74", null ],
            [ "Number of Points", "sparse_iq.html#autotoc_md75", null ],
            [ "Step Length", "sparse_iq.html#autotoc_md76", null ],
            [ "Profile", "sparse_iq.html#autotoc_md77", null ],
            [ "Hardware Accelerated Average Samples - HWAAS", "sparse_iq.html#autotoc_md78", null ],
            [ "Receiver Gain", "sparse_iq.html#autotoc_md79", null ],
            [ "TX Enable", "sparse_iq.html#autotoc_md80", null ],
            [ "Pulse Repetition Frequency", "sparse_iq.html#autotoc_md81", null ],
            [ "Phase Enhancement", "sparse_iq.html#autotoc_md82", null ],
            [ "Enable or disable loopback.", "sparse_iq.html#autotoc_md83", null ]
          ] ]
        ] ]
      ] ]
    ] ],
    [ "HAL Integration", "hal_integration.html", [
      [ "Acconeer EVK and Modules", "hal_integration.html#autotoc_md13", null ],
      [ "Acconeer Software Delivery", "hal_integration.html#autotoc_md14", null ],
      [ "HW Integration Overview", "hal_integration.html#autotoc_md15", [
        [ "GPIO Control Signals", "hal_integration.html#autotoc_md16", null ],
        [ "SPI Bus", "hal_integration.html#autotoc_md17", null ],
        [ "Power Control", "hal_integration.html#autotoc_md18", null ],
        [ "Crystal", "hal_integration.html#autotoc_md19", null ]
      ] ],
      [ "Prototype Integrations", "hal_integration.html#autotoc_md20", null ],
      [ "Software Integration", "hal_integration.html#autotoc_md21", [
        [ "HAL Struct", "hal_integration.html#autotoc_md22", [
          [ "The reference_frequency Property", "hal_integration.html#autotoc_md23", null ],
          [ "The max_spi_transfer_size Property", "hal_integration.html#autotoc_md24", null ],
          [ "Mem-alloc Function", "hal_integration.html#autotoc_md25", null ],
          [ "Mem-free Function", "hal_integration.html#autotoc_md26", null ],
          [ "Sensor Transfer Function", "hal_integration.html#autotoc_md27", null ],
          [ "Log Function", "hal_integration.html#autotoc_md28", null ],
          [ "16-bit Sensor Transfer Function", "hal_integration.html#autotoc_md29", null ]
        ] ],
        [ "HAL Integration Functions", "hal_integration.html#autotoc_md30", [
          [ "Sensor Supply On Function", "hal_integration.html#autotoc_md31", null ],
          [ "Sensor Supply Off Function", "hal_integration.html#autotoc_md32", null ],
          [ "Sensor Enable Function", "hal_integration.html#autotoc_md33", null ],
          [ "Sensor Disable Function", "hal_integration.html#autotoc_md34", null ],
          [ "Wait for Interrupt Function", "hal_integration.html#autotoc_md35", null ],
          [ "Sensor Count Function", "hal_integration.html#autotoc_md36", null ]
        ] ]
      ] ],
      [ "References, List of Documentation", "hal_integration.html#autotoc_md37", null ]
    ] ],
    [ "Assembly Test", "assembly.html", [
      [ "Setting up the Assembly Test", "assembly.html#autotoc_md0", [
        [ "Initializing the System", "assembly.html#autotoc_md1", null ],
        [ "Allocate Buffer", "assembly.html#autotoc_md2", null ],
        [ "Create Test", "assembly.html#autotoc_md3", null ],
        [ "Enable / Disable Tests", "assembly.html#autotoc_md4", null ]
      ] ],
      [ "Running the assembly test", "assembly.html#autotoc_md5", null ],
      [ "Get the assembly test result", "assembly.html#autotoc_md6", null ],
      [ "Deactivation and Destroy", "assembly.html#autotoc_md7", [
        [ "Basic Read Test", "assembly.html#autotoc_md8", null ],
        [ "Communication Test", "assembly.html#autotoc_md9", null ],
        [ "Enable Pin Test", "assembly.html#autotoc_md10", null ],
        [ "Interrupt Test", "assembly.html#autotoc_md11", null ],
        [ "Clock & Supply Test", "assembly.html#autotoc_md12", null ]
      ] ]
    ] ]
];