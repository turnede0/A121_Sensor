var examples =
[
    [ "acc_control_helper.c", "acc_control_helper_8c-example.html", null ],
    [ "acc_processing_helpers.c", "acc_processing_helpers_8c-example.html", null ],
    [ "example_bring_up.c", "example_bring_up_8c-example.html", null ],
    [ "example_control_helper.c", "example_control_helper_8c-example.html", null ],
    [ "example_detector_presence.c", "example_detector_presence_8c-example.html", null ],
    [ "example_detector_presence_multiple_configurations.c", "example_detector_presence_multiple_configurations_8c-example.html", null ],
    [ "example_diagnostic_test.c", "example_diagnostic_test_8c-example.html", null ],
    [ "example_low_power_presence_hibernate.c", "example_low_power_presence_hibernate_8c-example.html", null ],
    [ "example_low_power_presence_off.c", "example_low_power_presence_off_8c-example.html", null ],
    [ "example_processing_amplitude.c", "example_processing_amplitude_8c-example.html", null ],
    [ "example_processing_coherent_mean.c", "example_processing_coherent_mean_8c-example.html", null ],
    [ "example_processing_noncoherent_mean.c", "example_processing_noncoherent_mean_8c-example.html", null ],
    [ "example_processing_peak_interpolation.c", "example_processing_peak_interpolation_8c-example.html", null ],
    [ "example_processing_subtract_adaptive_bg.c", "example_processing_subtract_adaptive_bg_8c-example.html", null ],
    [ "example_service.c", "example_service_8c-example.html", null ],
    [ "example_service_hibernate.c", "example_service_hibernate_8c-example.html", null ],
    [ "example_service_multiple_configurations.c", "example_service_multiple_configurations_8c-example.html", null ],
    [ "example_service_subsweeps.c", "example_service_subsweeps_8c-example.html", null ]
];