var modules =
[
    [ "Presence Detector", "group__Presence.html", "group__Presence" ],
    [ "Service", "group__service.html", "group__service" ]
];