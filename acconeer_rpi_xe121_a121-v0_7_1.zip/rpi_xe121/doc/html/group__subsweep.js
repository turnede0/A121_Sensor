var group__subsweep =
[
    [ "acc_config_subsweep_index_t", "group__subsweep.html#gab471a635eaab375f4ec0ea4aa36409a3", [
      [ "ACC_CONFIG_SUBSWEEP_INDEX_0", "group__subsweep.html#ggab471a635eaab375f4ec0ea4aa36409a3ae3ae95582466c7323eafe2853e208f24", null ],
      [ "ACC_CONFIG_SUBSWEEP_INDEX_1", "group__subsweep.html#ggab471a635eaab375f4ec0ea4aa36409a3a7ba2f12be6147d3ba783fec793eff7ba", null ],
      [ "ACC_CONFIG_SUBSWEEP_INDEX_2", "group__subsweep.html#ggab471a635eaab375f4ec0ea4aa36409a3af470cc0b546726d88bab299271464821", null ],
      [ "ACC_CONFIG_SUBSWEEP_INDEX_3", "group__subsweep.html#ggab471a635eaab375f4ec0ea4aa36409a3a84048bf91ad9d763a4373589a64de7a0", null ],
      [ "ACC_CONFIG_SUBSWEEP_INDEX_COUNT", "group__subsweep.html#ggab471a635eaab375f4ec0ea4aa36409a3a89aa4f3d5f9f01beebef723d027b7aaa", null ]
    ] ],
    [ "acc_config_num_subsweeps_get", "group__subsweep.html#gac3e2735ecc8c7b7929d425875cc0b9a7", null ],
    [ "acc_config_num_subsweeps_set", "group__subsweep.html#gaa98e534f0b4beb592aed9fdc34f43984", null ],
    [ "acc_config_subsweep_enable_loopback_get", "group__subsweep.html#ga2c0aff792477aca21c4990f4125524cc", null ],
    [ "acc_config_subsweep_enable_loopback_set", "group__subsweep.html#gae837312616dc2ef362237a0d0192c657", null ],
    [ "acc_config_subsweep_enable_tx_get", "group__subsweep.html#ga61239088a103abfea65f5c85a0c75c86", null ],
    [ "acc_config_subsweep_enable_tx_set", "group__subsweep.html#gae84860b58303a4ce7ffee8a1e2c0a53a", null ],
    [ "acc_config_subsweep_hwaas_get", "group__subsweep.html#ga7e356e7967a4f5791e006ab3e1193a43", null ],
    [ "acc_config_subsweep_hwaas_set", "group__subsweep.html#gab901dd7f812cb09be68ee54f9bec9428", null ],
    [ "acc_config_subsweep_num_points_get", "group__subsweep.html#ga190c54f7bfb538252ee3392c7cf01055", null ],
    [ "acc_config_subsweep_num_points_set", "group__subsweep.html#ga801cbd75f36d2b2c6993b24685e33838", null ],
    [ "acc_config_subsweep_phase_enhancement_get", "group__subsweep.html#ga5c17b308438921b00be4e851571a5987", null ],
    [ "acc_config_subsweep_phase_enhancement_set", "group__subsweep.html#gab02f4c5364a81c3afa289d18b6a418d4", null ],
    [ "acc_config_subsweep_prf_get", "group__subsweep.html#gafcc80b9b73773dfcafa968b9ba9d296e", null ],
    [ "acc_config_subsweep_prf_set", "group__subsweep.html#ga189e2448127a9e86cbda91d6cae1699d", null ],
    [ "acc_config_subsweep_profile_get", "group__subsweep.html#ga3480544ad90c0ce90a8a07d1941f4a08", null ],
    [ "acc_config_subsweep_profile_set", "group__subsweep.html#ga66aa2972a2ccc858a74a8da6736dd696", null ],
    [ "acc_config_subsweep_receiver_gain_get", "group__subsweep.html#ga3bcadffc7cae31d128c8770c4947e6bd", null ],
    [ "acc_config_subsweep_receiver_gain_set", "group__subsweep.html#gaa852655fef23921261ca2693e4e57164", null ],
    [ "acc_config_subsweep_start_point_get", "group__subsweep.html#gad95bc8dfebcc6937e4987ccc665d8867", null ],
    [ "acc_config_subsweep_start_point_set", "group__subsweep.html#ga2f3d709c5e8fff98d23d1b7994d3d9d6", null ],
    [ "acc_config_subsweep_step_length_get", "group__subsweep.html#gac7b14dc40c16ca721f31649c888de3b4", null ],
    [ "acc_config_subsweep_step_length_set", "group__subsweep.html#gabe591e87af279e13e270e0f6a6443c84", null ]
];