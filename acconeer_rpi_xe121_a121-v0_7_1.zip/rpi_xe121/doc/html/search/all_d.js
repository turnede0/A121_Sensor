var searchData=
[
  ['pin_412',['pin',['../structgpio__config__t.html#a9a1ddeff55ba52e15aba21de5f7113c0',1,'gpio_config_t']]],
  ['pin_5fhigh_413',['PIN_HIGH',['../acc__libgpiod_8h.html#a7de4bc273324613e5bbff8825af553e3a75e7ef64e7e3e078a6d2a7cc2d790226',1,'acc_libgpiod.h']]],
  ['pin_5flow_414',['PIN_LOW',['../acc__libgpiod_8h.html#a7de4bc273324613e5bbff8825af553e3af6ea07d163784d7bef21d4c12fa77ec7',1,'acc_libgpiod.h']]],
  ['poll_5fevents_415',['poll_events',['../acc__exploration__server__linux_8c.html#ac5528f4d133b3dd7e5fba94e4d30de24',1,'acc_exploration_server_linux.c']]],
  ['poll_5fset_416',['poll_set',['../structexploration__server__t.html#ae5efd953642e09e90f45f753dacc7dbf',1,'exploration_server_t']]],
  ['presence_20detector_417',['Presence Detector',['../group__Presence.html',1,'']]],
  ['presence_5fdetected_418',['presence_detected',['../structacc__detector__presence__result__t.html#a0cba70bf4b4b25e6a5a5f2531c6d2b24',1,'acc_detector_presence_result_t']]],
  ['presence_5fdistance_419',['presence_distance',['../structacc__detector__presence__result__t.html#a343b878eb3c9fc86a615197133907a85',1,'acc_detector_presence_result_t']]],
  ['prifloat_420',['PRIfloat',['../acc__integration__log_8h.html#aee8d9cf62aafbefd700bfade845d1b23',1,'acc_integration_log.h']]],
  ['print_5fdata_421',['print_data',['../example__control__helper_8c.html#a7d95800e8efa98ec178ac5886619f85c',1,'print_data(acc_int16_complex_t *data, uint16_t data_length):&#160;example_control_helper.c'],['../example__service_8c.html#a7d95800e8efa98ec178ac5886619f85c',1,'print_data(acc_int16_complex_t *data, uint16_t data_length):&#160;example_service.c'],['../example__service__hibernate_8c.html#a7d95800e8efa98ec178ac5886619f85c',1,'print_data(acc_int16_complex_t *data, uint16_t data_length):&#160;example_service_hibernate.c'],['../example__service__multiple__configurations_8c.html#a4da520f948b34161343621d78c47af24',1,'print_data(acc_int16_complex_t *data, uint16_t data_length, uint32_t cfg):&#160;example_service_multiple_configurations.c'],['../example__service__subsweeps_8c.html#a7d95800e8efa98ec178ac5886619f85c',1,'print_data(acc_int16_complex_t *data, uint16_t data_length):&#160;example_service_subsweeps.c']]],
  ['print_5fresult_422',['print_result',['../example__detector__presence_8c.html#aa4c1d8b3fb4af734d056b00692e44056',1,'print_result(acc_detector_presence_result_t result):&#160;example_detector_presence.c'],['../example__detector__presence__multiple__configurations_8c.html#a12c964cea9cfbc923074580255b2cbb9',1,'print_result(acc_detector_presence_result_t result, const char *config_name):&#160;example_detector_presence_multiple_configurations.c'],['../example__low__power__presence__hibernate_8c.html#aa4c1d8b3fb4af734d056b00692e44056',1,'print_result(acc_detector_presence_result_t result):&#160;example_low_power_presence_hibernate.c'],['../example__low__power__presence__off_8c.html#aa4c1d8b3fb4af734d056b00692e44056',1,'print_result(acc_detector_presence_result_t result):&#160;example_low_power_presence_off.c']]],
  ['print_5fusage_423',['print_usage',['../acc__exploration__server__linux_8c.html#aeaa89970561bd34a6bce01b439d95a9a',1,'acc_exploration_server_linux.c']]],
  ['printf_5fattribute_5fcheck_424',['PRINTF_ATTRIBUTE_CHECK',['../acc__integration__log_8h.html#a6b613fe1b4f84778f29a0ea237ac22f7',1,'acc_integration_log.h']]],
  ['prisensor_5fid_425',['PRIsensor_id',['../acc__definitions__common_8h.html#ae2ddc82b4481619b79cd8cafe9e43836',1,'acc_definitions_common.h']]],
  ['proc_5fmeta_426',['proc_meta',['../structacc__control__helper__t.html#aa95ebc5115ba86d7726773e6158feb3f',1,'acc_control_helper_t']]],
  ['proc_5fresult_427',['proc_result',['../structacc__control__helper__t.html#ab1dd77bff06018a0446f84a336bfa271',1,'acc_control_helper_t']]],
  ['processing_428',['processing',['../structacc__control__helper__t.html#a452f090777cf2f32417d1917ec5950a3',1,'acc_control_helper_t::processing()'],['../group__processing.html',1,'(Global Namespace)']]],
  ['processing_5fresult_429',['processing_result',['../structacc__detector__presence__result__t.html#a26fc3231e57878d193cfe29d223df97a',1,'acc_detector_presence_result_t']]]
];
