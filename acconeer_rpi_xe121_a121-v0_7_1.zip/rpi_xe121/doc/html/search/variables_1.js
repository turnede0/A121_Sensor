var searchData=
[
  ['cal_5fresult_777',['cal_result',['../structacc__control__helper__t.html#a47b01a74dcfcc3217d03a0737b03660b',1,'acc_control_helper_t']]],
  ['calibration_5fneeded_778',['calibration_needed',['../structacc__processing__result__t.html#af049f80966de91d326460d91e3065151',1,'acc_processing_result_t']]],
  ['chip_779',['chip',['../acc__libgpiod_8c.html#aaddc701b695be2b39390334da05025e9',1,'acc_libgpiod.c']]],
  ['client_5fsocket_780',['client_socket',['../structexploration__server__t.html#abd6790a57b89b7de3742143a6e79112d',1,'exploration_server_t']]],
  ['command_5fbuffer_781',['command_buffer',['../acc__exploration__server__linux_8c.html#a584850828ad0ab590bbdab7ce901b19c',1,'acc_exploration_server_linux.c']]],
  ['config_782',['config',['../structacc__control__helper__t.html#adad070b1446fad5dc97954d889e0a9e2',1,'acc_control_helper_t']]]
];
