var searchData=
[
  ['max_5fbaudrate_800',['max_baudrate',['../structexploration__server__interface__t.html#a70e3e701bf72d5129338aadd7f475c09',1,'exploration_server_interface_t']]],
  ['max_5fspi_5ftransfer_5fsize_801',['max_spi_transfer_size',['../structacc__hal__a121__t.html#a6927f0dd6670568c1787148e4c6b5ee6',1,'acc_hal_a121_t']]],
  ['max_5fsweep_5frate_802',['max_sweep_rate',['../structacc__processing__metadata__t.html#ad61e148337afc774aab38398d0e1a56e',1,'acc_processing_metadata_t']]],
  ['mem_5falloc_803',['mem_alloc',['../structacc__hal__a121__t.html#a1efdd6378356e90e79e37d1d689ec671',1,'acc_hal_a121_t']]],
  ['mem_5ffree_804',['mem_free',['../structacc__hal__a121__t.html#a1bce7dea666226fd29fa447559aba0cb',1,'acc_hal_a121_t']]]
];
