var searchData=
[
  ['gpio_5fconfig_5ft_494',['gpio_config_t',['../structgpio__config__t.html',1,'']]],
  ['gpio_5fpin_5ft_495',['gpio_pin_t',['../structgpio__pin__t.html',1,'']]]
];
