var searchData=
[
  ['set_5fconfig_767',['set_config',['../example__low__power__presence__hibernate_8c.html#a3190660825318b10df8fa99ec238c0b8',1,'set_config(acc_detector_presence_config_t *presence_config):&#160;example_low_power_presence_hibernate.c'],['../example__low__power__presence__off_8c.html#a3190660825318b10df8fa99ec238c0b8',1,'set_config(acc_detector_presence_config_t *presence_config):&#160;example_low_power_presence_off.c']]],
  ['set_5fshutdown_768',['set_shutdown',['../acc__exploration__server__linux_8c.html#a54534f41829881c13c6a410e8ec5fd4f',1,'acc_exploration_server_linux.c']]],
  ['setup_5fclient_5fsocket_769',['setup_client_socket',['../acc__exploration__server__linux_8c.html#ac78628871fd231b73d8a06e30ed40ecd',1,'acc_exploration_server_linux.c']]],
  ['signal_5fhandler_770',['signal_handler',['../rf__certification__test_8c.html#af675374954cdabdf63d036fe3c12d348',1,'rf_certification_test.c']]],
  ['start_5fserver_5fsocket_771',['start_server_socket',['../acc__exploration__server__linux_8c.html#aa2404104aeee45fbdbd387797153c9cb',1,'acc_exploration_server_linux.c']]]
];
