var searchData=
[
  ['frame_789',['frame',['../structacc__processing__result__t.html#a5503fe9df13abfa5a41b91b11df8c6c9',1,'acc_processing_result_t']]],
  ['frame_5fdata_5flength_790',['frame_data_length',['../structacc__processing__metadata__t.html#a538adef49d0e7769a3e01659319ca34c',1,'acc_processing_metadata_t']]],
  ['frame_5fdelayed_791',['frame_delayed',['../structacc__processing__result__t.html#a3a6ae77523137690fa8833c9e5e31fe0',1,'acc_processing_result_t']]],
  ['frame_5frate_792',['frame_rate',['../structexample__config.html#af726c9ed0c78af1f48d99461ae26e089',1,'example_config']]]
];
