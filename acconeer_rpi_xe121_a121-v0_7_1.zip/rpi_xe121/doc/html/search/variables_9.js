var searchData=
[
  ['name_805',['name',['../structexample__config.html#ac33d422f1ce6b941e20d7405b4bf35fa',1,'example_config']]],
  ['num_5fpoints_806',['num_points',['../structexample__config.html#a0b5c7546af8a859ed661b1d1c949c001',1,'example_config']]]
];
