var searchData=
[
  ['user_20guides_471',['User guides',['../md__home_ai_jenkins_workspace_sw-main_0d2_doc_user_guides_a121_rss_user_guide_main.html',1,'']]],
  ['update_5fconfiguration_472',['update_configuration',['../example__processing__amplitude_8c.html#a5b68ec7952053d1b3471ce12ee7e16c8',1,'update_configuration(acc_config_t *config):&#160;example_processing_amplitude.c'],['../example__processing__coherent__mean_8c.html#a5b68ec7952053d1b3471ce12ee7e16c8',1,'update_configuration(acc_config_t *config):&#160;example_processing_coherent_mean.c'],['../example__processing__noncoherent__mean_8c.html#a5b68ec7952053d1b3471ce12ee7e16c8',1,'update_configuration(acc_config_t *config):&#160;example_processing_noncoherent_mean.c'],['../example__processing__peak__interpolation_8c.html#a5b68ec7952053d1b3471ce12ee7e16c8',1,'update_configuration(acc_config_t *config):&#160;example_processing_peak_interpolation.c'],['../example__processing__subtract__adaptive__bg_8c.html#a5b68ec7952053d1b3471ce12ee7e16c8',1,'update_configuration(acc_config_t *config):&#160;example_processing_subtract_adaptive_bg.c']]],
  ['us_5fticks_5fper_5fsecond_473',['US_TICKS_PER_SECOND',['../acc__exploration__server__linux_8c.html#a2add818c395d6a5aa1d8c218690b4d77',1,'acc_exploration_server_linux.c']]],
  ['user_5fguide_5fmain_2emd_474',['user_guide_main.md',['../user__guide__main_8md.html',1,'']]]
];
