var searchData=
[
  ['buffer_775',['buffer',['../structacc__control__helper__t.html#ade1bb9232d2a09e4d6716b527825530f',1,'acc_control_helper_t']]],
  ['buffer_5fsize_776',['buffer_size',['../structacc__control__helper__t.html#affb4d870aca292c81ff1497ddb6fb409',1,'acc_control_helper_t']]]
];
