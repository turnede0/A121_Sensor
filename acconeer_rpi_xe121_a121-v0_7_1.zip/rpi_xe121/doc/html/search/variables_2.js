var searchData=
[
  ['data_783',['data',['../structacc__cal__result__t.html#af8d56d3782b7051a63642e8ab9450f98',1,'acc_cal_result_t::data()'],['../structacc__vector__iq__t.html#a7fbb8feaf7c15c2ccf1c2b281316e2e5',1,'acc_vector_iq_t::data()'],['../structacc__vector__float__t.html#a6ed3f18a02a02c271efd6bce14302ef5',1,'acc_vector_float_t::data()']]],
  ['data_5flength_784',['data_length',['../structacc__vector__iq__t.html#afab97bbae99aac9ce7b41cf141367abb',1,'acc_vector_iq_t::data_length()'],['../structacc__vector__float__t.html#a16093302d00543101e3c84b92eb5b644',1,'acc_vector_float_t::data_length()']]],
  ['data_5fsaturated_785',['data_saturated',['../structacc__processing__result__t.html#aca881efd8c63d870d5f56b0358a2b814',1,'acc_processing_result_t']]],
  ['direction_786',['direction',['../structgpio__config__t.html#a1692ceaf2268df7106e31a82b5f8f29e',1,'gpio_config_t::direction()'],['../structgpio__pin__t.html#a7445160187d25cb0bf0878e984adecd1',1,'gpio_pin_t::direction()']]]
];
