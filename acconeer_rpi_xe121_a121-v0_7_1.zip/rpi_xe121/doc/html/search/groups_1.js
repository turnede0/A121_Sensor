var searchData=
[
  ['presence_20detector_956',['Presence Detector',['../group__Presence.html',1,'']]],
  ['processing_957',['Processing',['../group__processing.html',1,'']]]
];
