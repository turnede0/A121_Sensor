var searchData=
[
  ['name_406',['name',['../structexample__config.html#ac33d422f1ce6b941e20d7405b4bf35fa',1,'example_config']]],
  ['nbr_5fconfigs_407',['NBR_CONFIGS',['../example__detector__presence__multiple__configurations_8c.html#a1fec70214cc8646925d859f523644224',1,'NBR_CONFIGS():&#160;example_detector_presence_multiple_configurations.c'],['../example__service__multiple__configurations_8c.html#a1fec70214cc8646925d859f523644224',1,'NBR_CONFIGS():&#160;example_service_multiple_configurations.c']]],
  ['nbr_5fiterations_5fper_5fconfig_408',['NBR_ITERATIONS_PER_CONFIG',['../example__detector__presence__multiple__configurations_8c.html#a2ac6b8300e1d163f92de795e1653fa50',1,'example_detector_presence_multiple_configurations.c']]],
  ['ns_5fper_5fticks_409',['NS_PER_TICKS',['../acc__exploration__server__linux_8c.html#ab4fa27f24e228a15cb4ea3925cd777a2',1,'acc_exploration_server_linux.c']]],
  ['num_5fpoints_410',['num_points',['../structexample__config.html#a0b5c7546af8a859ed661b1d1c949c001',1,'example_config']]]
];
