var searchData=
[
  ['sensor_819',['sensor',['../structacc__control__helper__t.html#abc91059068a1c0db2731fecdfb94dad1',1,'acc_control_helper_t']]],
  ['sensor_5fid_820',['sensor_id',['../structacc__control__helper__t.html#a248ac07927e3ab69c5206bb6ce156665',1,'acc_control_helper_t']]],
  ['server_5fif_821',['server_if',['../acc__exploration__server__linux_8c.html#ad5265fc1296bd8b435cb7fc3de9720e0',1,'acc_exploration_server_linux.c']]],
  ['server_5fsocket_822',['server_socket',['../structexploration__server__t.html#a6765bc49a131b09b3e1d24cfdd0dadd9',1,'exploration_server_t']]],
  ['set_5fbaudrate_823',['set_baudrate',['../structexploration__server__interface__t.html#a8d52cb81e49ecdcc9f163eb7810a824e',1,'exploration_server_interface_t']]],
  ['shutdown_824',['shutdown',['../structexploration__server__t.html#ab69a635b1744077c9fe19f157f915fdb',1,'exploration_server_t']]],
  ['socket_5fbuffer_825',['socket_buffer',['../acc__exploration__server__linux_8c.html#a048d516b3f9919f9eea6da8bc2f8ff99',1,'acc_exploration_server_linux.c']]],
  ['spi_5ffd_826',['spi_fd',['../acc__libspi_8c.html#a08bc620566448265a66e6f37aae5d775',1,'acc_libspi.c']]],
  ['start_827',['start',['../structexample__config.html#a510cfa2051fdfe538d2405100b527d25',1,'example_config']]],
  ['start_5fpoint_828',['start_point',['../structexample__config.html#a4d4c63851da8f2edb324ca53bf05d7e5',1,'example_config']]],
  ['subsweep_5fdata_5flength_829',['subsweep_data_length',['../structacc__processing__metadata__t.html#a6eb0b3bf6b195c4e7fa9927b08d0689b',1,'acc_processing_metadata_t']]],
  ['subsweep_5fdata_5foffset_830',['subsweep_data_offset',['../structacc__processing__metadata__t.html#a109a54d4d324b3c1f49c3c6e7b62f5f1',1,'acc_processing_metadata_t']]],
  ['sweep_5fdata_5flength_831',['sweep_data_length',['../structacc__processing__metadata__t.html#a64bf2bfb5bb3c4063639b9d1a62f14d3',1,'acc_processing_metadata_t']]],
  ['sweeps_5fper_5fframe_832',['sweeps_per_frame',['../structexample__config.html#a1c1b86fa9e0e931a80170f4c935a6d50',1,'example_config']]]
];
