var searchData=
[
  ['sparse_5fiq_2emd_542',['sparse_iq.md',['../sparse__iq_8md.html',1,'']]]
];
