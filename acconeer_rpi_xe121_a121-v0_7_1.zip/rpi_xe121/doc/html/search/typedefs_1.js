var searchData=
[
  ['example_5fconfig_5ft_854',['example_config_t',['../example__detector__presence__multiple__configurations_8c.html#adf8cf94b0a15a7307efcd523675a4eab',1,'example_config_t():&#160;example_detector_presence_multiple_configurations.c'],['../example__service__multiple__configurations_8c.html#adf8cf94b0a15a7307efcd523675a4eab',1,'example_config_t():&#160;example_service_multiple_configurations.c']]]
];
