var searchData=
[
  ['imag_795',['imag',['../structacc__int16__complex__t.html#abf752ab60679b63de25256a49205f081',1,'acc_int16_complex_t']]],
  ['inter_5fpresence_5fscore_796',['inter_presence_score',['../structacc__detector__presence__result__t.html#a125c96c077a35896117085d6b07060a7',1,'acc_detector_presence_result_t']]],
  ['intra_5fpresence_5fscore_797',['intra_presence_score',['../structacc__detector__presence__result__t.html#adc7704eca7252b12f3744a3fa208f99d',1,'acc_detector_presence_result_t']]]
];
