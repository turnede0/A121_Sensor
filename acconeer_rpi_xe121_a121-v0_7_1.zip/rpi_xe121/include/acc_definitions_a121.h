// Copyright (c) Acconeer AB, 2022
// All rights reserved

#ifndef ACC_DEFINITIONS_A121_H_
#define ACC_DEFINITIONS_A121_H_

#include <stdint.h>

#define ACC_CAL_RESULT_DATA_SIZE (192)

/**
 * The result from a completed calibration.
 */
typedef struct
{
	uint8_t data[ACC_CAL_RESULT_DATA_SIZE];
} acc_cal_result_t;

/**
 * Information about calibration.
 */
typedef struct
{
	int16_t temperature;
} acc_cal_info_t;


/**
 * @brief Profile
 *
 */
typedef enum
{
	ACC_CONFIG_PROFILE_1 = 1,
	ACC_CONFIG_PROFILE_2,
	ACC_CONFIG_PROFILE_3,
	ACC_CONFIG_PROFILE_4,
	ACC_CONFIG_PROFILE_5,
} acc_config_profile_t;


/**
 * @brief Idle state
 *
 * Idle state 'DEEP_SLEEP' is the deepest state where as much of the sensor hardware as
 * possible is shut down and idle state 'READY' is the shallowest state where most of the sensor
 * hardware is kept on.
 *
 * DEEP_SLEEP is the slowest to transition from while READY is the fastest.
 *
 */
typedef enum
{
	ACC_CONFIG_IDLE_STATE_DEEP_SLEEP,
	ACC_CONFIG_IDLE_STATE_SLEEP,
	ACC_CONFIG_IDLE_STATE_READY,
} acc_config_idle_state_t;

#endif
