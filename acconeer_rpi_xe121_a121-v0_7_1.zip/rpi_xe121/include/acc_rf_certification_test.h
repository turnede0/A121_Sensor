// Copyright (c) Acconeer AB, 2022
// All rights reserved

#ifndef ACC_RF_CERTIFICATION_TEST_H_
#define ACC_RF_CERTIFICATION_TEST_H_

#include <stdbool.h>
#include <stdint.h>

/**
 * @brief Execute the RF certification test
 *
 * @param argc Argument count
 * @param argv Argument vector
 *
 * @return Returns EXIT_SUCCESS if successful, otherwise EXIT_FAILURE
 */
int acc_rf_certification_test_standalone(int argc, char *argv[]);


/**
 * @brief Stops the testing (only applicable for a linux host)
 */
void acc_rf_certification_test_stop_set(void);


/**
 * @brief Execute the RF certification test
 *
 * @param iterations The number of iterations, set to 0 to run infinite number of iterations
 * @param tx_disable Set to true to disable TX, false overwise
 * @param rx_test Set to true to run RX test instead of TX test, false overwise
 *
 * @return True if executed successfully, false if not
 */
bool acc_rf_certification(uint32_t iterations, bool tx_disable, bool rx_test);


#endif
