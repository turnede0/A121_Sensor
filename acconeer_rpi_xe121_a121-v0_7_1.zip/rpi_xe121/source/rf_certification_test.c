// Copyright (c) Acconeer AB, 2022
// All rights reserved
// This file is subject to the terms and conditions defined in the file
// 'LICENSES/license_acconeer.txt', (BSD 3-Clause License) which is part
// of this source code package.

#include <stddef.h>
#include <stdint.h>

#include "acc_rf_certification_test.h"

#include <signal.h>


/**
 * @brief Handle interrupt signals
 *
 * @param signum Signal number sent
 */
static void signal_handler(int signum);


int main(int argc, char *argv[]);


int main(int argc, char *argv[])
{
	signal(SIGINT, signal_handler);
	signal(SIGTERM, signal_handler);

	return acc_rf_certification_test_standalone(argc, argv);
}


void signal_handler(int signum)
{
	(void)signum;
	acc_rf_certification_test_stop_set();
}
